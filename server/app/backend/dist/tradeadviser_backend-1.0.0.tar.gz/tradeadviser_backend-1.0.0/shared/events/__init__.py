"""Shared event-envelope package."""

