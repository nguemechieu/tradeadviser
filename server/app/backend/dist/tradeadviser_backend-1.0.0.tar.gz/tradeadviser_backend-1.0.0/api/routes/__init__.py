"""REST route registration package."""

